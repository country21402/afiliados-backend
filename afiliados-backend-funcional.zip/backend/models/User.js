
const pool = require('../config/db');
const bcrypt = require('bcrypt');

async function createUser(name, email, password, referredBy = null) {
    const hashedPassword = await bcrypt.hash(password, 10);
    const referralCode = Math.random().toString(36).substring(2, 8);
    const result = await pool.query(
        'INSERT INTO users (name, email, password, referral_code, referred_by) VALUES ($1, $2, $3, $4, $5) RETURNING *',
        [name, email, hashedPassword, referralCode, referredBy]
    );
    return result.rows[0];
}

async function getUserByEmail(email) {
    const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    return result.rows[0];
}

module.exports = { createUser, getUserByEmail };
